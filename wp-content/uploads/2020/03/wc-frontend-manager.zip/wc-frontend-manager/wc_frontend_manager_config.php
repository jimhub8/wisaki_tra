<?php

define('WCFM_TOKEN', 'wcfm');

define('WCFM_TEXT_DOMAIN', 'wc-frontend-manager');

define('WCFM_VERSION', '6.4.3');

define('WCFM_SERVER_URL', 'https://wclovers.com');

?>