<?php

/**
 * An array of flat rate box pricing - 2016
 */
return array(

	"USPS"	=>	array(
		"FlatRateEnvelope"     => array(
			"commercial"	=> "5.60",
		),
		"FlatRateGiftCardEnvelope"     => array(
			"commercial"	=> "5.60",
		),
		"FlatRateWindowEnvelope"     => array(
			"commercial"	=> "5.60",
		),
		"SmallFlatRateEnvelope"     => array(
			"commercial"	=> "5.60",
		),
		"FlatRatePaddedEnvelope"     => array(
			"commercial"	=> "5.90",
		),
		"FlatRateLegalEnvelope"     => array(
			"commercial"	=> "5.60",
		),
		"SmallFlatRateBox"     => array(
			"commercial"	=> "5.90",
		),
		"MediumFlatRateBox"     => array(
			"commercial"	=> "11.60",
		),
		"MediumFlatRateBox_b"     => array(
			"commercial"	=> "11.60",
		),
		"LargeFlatRateBox"     => array(
			"commercial"	=> "15.85",
		),
		"LargeFlatRateBoardGameBox"     => array(
			"commercial"	=> "15.85",
		),
	),
);
