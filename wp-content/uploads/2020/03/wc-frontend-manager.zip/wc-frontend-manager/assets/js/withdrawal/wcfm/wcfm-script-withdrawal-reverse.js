jQuery(document).ready(function($) {
		
	$status_type = $('#dropdown_status_type').val();
	$withdrawal_vendor = '';
		
	$wcfm_reverse_withdrawal_requests_table = $('#wcfm-reverse-withdrawal-requests').DataTable( {
		"processing": true,
		"serverSide": true,
		"pageLength": parseInt(dataTables_config.pageLength),
		"bFilter"   : false,
		"dom"       : 'Bfrtip',
		"responsive": true,
		"language"  : $.parseJSON(dataTables_language),
		"buttons"   : $wcfm_datatable_button_args,
		"columns"   : [
										{ responsivePriority: 2 },
										{ responsivePriority: 1 },
										{ responsivePriority: 3 },
										{ responsivePriority: 5 },
										{ responsivePriority: 4 },
										{ responsivePriority: 1 },
										{ responsivePriority: 6 },
										{ responsivePriority: 5 }
								],
		"columnDefs": [ { "targets": 0, "orderable" : false }, 
									  { "targets": 1, "orderable" : false }, 
										{ "targets": 2, "orderable" : false }, 
										{ "targets": 3, "orderable" : false }, 
										{ "targets": 4, "orderable" : false },
										{ "targets": 5, "orderable" : false },
										{ "targets": 6, "orderable" : false },
										{ "targets": 7, "orderable" : false },
									],
		'ajax': {
			"type"   : "POST",
			"url"    : wcfm_params.ajax_url,
			"data"   : function( d ) {
				d.action              = 'wcfm_ajax_controller',
				d.controller          = 'wcfm-withdrawal-reverse',
				d.status_type         = $status_type,
				d.withdrawal_vendor   = $withdrawal_vendor,
				d.start_date          = $filter_date_form,
				d.end_date            = $filter_date_to
				d.order               = 'desc'
			},
			"complete" : function () {
				initiateTip();
				
				// Fire wcfm-withdrawal table refresh complete
				$( document.body ).trigger( 'updated_wcfm-reverse-withdrawal-requests' );
			}
		}
	} );
	
	// Request Withdrawals Approve
	$('#wcfm_reverse_withdrawal_requests_approve_button').click(function(event) {
	  event.preventDefault();
	  
		$('#wcfm-content').block({
			message: null,
			overlayCSS: {
				background: '#fff',
				opacity: 0.6
			}
		});
		var data = {
			action                      : 'wcfm_ajax_controller',
			controller                  : 'wcfm-withdrawal-reverse-approve',
			wcfm_withdrawal_manage_form : $('#wcfm_reverse_withdrawal_requests_manage_form').serialize(),
			status                      : 'submit'
		}	
		$.post(wcfm_params.ajax_url, data, function(response) {
			if(response) {
				$response_json = $.parseJSON(response);
				$('.wcfm-message').html('').removeClass('wcfm-success').removeClass('wcfm-error').slideUp();
				wcfm_notification_sound.play();
				if($response_json.status) {
					$('#wcfm_reverse_withdrawal_requests_manage_form .wcfm-message').html('<span class="wcicon-status-completed"></span>' + $response_json.message).addClass('wcfm-success').slideDown();
					$wcfm_reverse_withdrawal_requests_table.ajax.reload();	
				} else {
					$('#wcfm_reverse_withdrawal_requests_manage_form .wcfm-message').html('<span class="wcicon-status-cancelled"></span>' + $response_json.message).addClass('wcfm-error').slideDown();
				}
				wcfmMessageHide();
				$('#withdraw_note').val('');
				$('#wcfm-content').unblock();
			}
		});
	});
	
	$( document.body ).on( 'wcfm-date-range-refreshed', function() {
		$wcfm_reverse_withdrawal_requests_table.ajax.reload();
	});
	
	if( $('#dropdown_vendor').length > 0 ) {
		$('#dropdown_vendor').on('change', function() {
			$withdrawal_vendor = $('#dropdown_vendor').val();
			$wcfm_reverse_withdrawal_requests_table.ajax.reload();
		}).select2( $wcfm_vendor_select_args );
	}
	
	$('#dropdown_status_type').change(function() {
		$status_type = $(this).val();
		$wcfm_reverse_withdrawal_requests_table.ajax.reload();
	});
	
	// Dashboard FIlter
	if( $('.wcfm_filters_wrap').length > 0 ) {
		$('.dataTable').before( $('.wcfm_filters_wrap') );
		$('.wcfm_filters_wrap').css( 'display', 'inline-block' );
	}
} );